Thank you for get this typeface! 

This font was designed from the lettering work made for Elkin Robinson by Mateo Rivano and David Espinosa. 
If you want to donnate or make contact,
please don't doubt it. Write me to david.ignorant@gmail.com or d.espinosa.mar@gmail.com

Copyright 2014. Type Sailor-David Espinosa & Don Temor-Mateo Rivano. Just for personal use.
